# lyx-sn
Lyx layout and example for Springer Nature
